from pathlib import Path
import gzip,hashlib,json
r=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion');bundle=r/'benchmarks/runs/pilot-v1.zhtlKh/results';summary=json.loads((bundle/'summary.json').read_text());manifest=json.loads((bundle/'manifest.json').read_text());text=(r/'benchmarks/results-20261015.md').read_text();budget=None;checked=0

def get(mode,condition,budget,subset):
    return next(g for g in summary['groups'] if g['mode']==mode and g['condition']==condition and g['budget']==budget and g['subset']==subset and g['precision']=='declared' and g['loss']=='huber')
for line in text.splitlines():
    if line=='## Equal capture time':budget='equal_time'
    if line=='## Equal raw sample control':budget='equal_samples'
    if not (line.startswith('| Pose |') or line.startswith('| Geometry |')):continue
    cells=[x.strip() for x in line.split('|')[1:-1]];mode=int(cells[0]=='Geometry');condition=cells[1]
    a,b,ab=[get(mode,condition,budget,c) for c in ('A','B','AB')]
    assert [int(v) for v in cells[2:5]]==[s['spatial_usability']['count'] for s in (a,b,ab)]
    assert int(cells[5])==ab['acceptance']['count']
    assert cells[6]==f"{ab['accepted_wrong']['count']}/{ab['accepted_wrong']['total']}"
    expected='—' if ab['coverage_95_joint']['total']==0 else f"{ab['coverage_95_joint']['count']}/{ab['coverage_95_joint']['total']}"
    assert cells[7]==expected
    expected='—' if ab['position_error_m'] is None else f"{1000*ab['position_error_m']['p95']:.3f}"
    assert cells[8]==expected,(cells,expected)
    checked+=1
assert checked==40
assert f"{get(0,'noise','equal_time','A')['position_error_m']['p95']*1000:.3f}"=='0.676'
b=get(0,'camera_bias','equal_time','B');assert b['coverage_95_joint']['count']==0 and b['coverage_95_joint']['total']==28
for condition in ('clean','weak_complementary'):
    for single in ('A','B'):
        pair=next(c for c in summary['paired_comparisons'] if c['mode']==1 and c['condition']==condition and c['budget']=='equal_time' and c['precision']=='declared' and c['loss']=='huber' and c['comparison']=='AB-'+single)
        assert pair['spatially_usable_delta']['mean']==1 and pair['spatially_usable_delta']['paired_95_interval']==[1.,1.]
pair=next(c for c in summary['paired_comparisons'] if c['mode']==0 and c['condition']=='noise' and c['budget']=='equal_time' and c['precision']=='declared' and c['loss']=='huber' and c['comparison']=='AB-A')
assert pair['spatially_usable_delta']['paired_95_interval']==[-.1,.1]
public=r/'benchmarks/evidence/pilot-20261015'
assert hashlib.sha256(gzip.decompress((public/'requests.jsonl.gz').read_bytes())).hexdigest()==manifest['artifacts']['requests.jsonl']
for a,b in [('summary.json','summary.json'),('manifest.json','manifest.json')]:assert (public/a).read_bytes()==(bundle/b).read_bytes()
assert (public/'cache-index.json').read_bytes()==(bundle.parent/'cache/index.json').read_bytes()
print(json.dumps({'table_rows_verified':checked,'consequential_claims_verified':['clean/complementary paired intervals','noisy-pose AB-A interval','noisy A p95','individual-camera biased coverage'],'compressed_requests_roundtrip_sha256':manifest['artifacts']['requests.jsonl'],'public_original_summary_manifest_index_byte_identical':True},indent=2))

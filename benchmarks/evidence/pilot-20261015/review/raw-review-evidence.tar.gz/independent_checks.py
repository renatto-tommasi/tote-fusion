"""Reviewer authored discriminating checks; no estimator truth dependency."""
import copy, hashlib, json, math, pathlib, sys
import numpy as np
from scipy.spatial.transform import Rotation
sys.path.insert(0, '/tmp/paired-core-verify-20261015/benchmarks')
from metrics import score, proportion, summarize
from scenes import render, scene_digest
ROOT=pathlib.Path('/tmp/paired-core-verify-20261015')
criteria=json.loads((ROOT/'benchmarks/criteria.json').read_text())
checks=[]
def record(name): checks.append(name)
# Nonidentity camera orientation: central optical ray is transformed +X in world.
R=Rotation.from_euler('y', math.pi/2).as_matrix()
depth,_=render(np.array([[[1.,-.7,-.7],[1.3,.7,.7]]]), np.array([-.5,0.,0.]),R,3,3,10.)
assert abs(depth[1,1]-1.5)<1e-12
record('nonidentity optical axial first-hit depth = 1.5m')
# Independently derived full covariance quadratic form with translation/dimension cross term.
truth={'pose':np.eye(4).tolist(),'dimensions':[.6,.4,.23]}
inputs={'scene_id':'independent','seed':100888,'partition':'pilot','mode':1,'condition':'clean','cache_digest':'reviewer','required_dimension_axes':[1]}
row={'accepted':True,'pose':np.eye(4).tolist(),'dimensions':[[.6],[.397],[.23]],'dimension_axes':[1], 'compute_s':0.,'stage':'pixel_core','subset':'AB','precision':'declared','loss':'huber','budget':'equal_time','code':'OK'}
row['pose'][0][3]=-.003
cov=np.eye(7)*1e-6;cov[0,6]=cov[6,0]=.5e-6;row['covariance']=cov.tolist()
r=score(copy.deepcopy(row),inputs,truth,criteria)
assert abs(r['joint_nees']-12)<1e-10
assert r['position_error_m']==.003
record('joint covariance 2x2 analytic inverse gives NEES 12, diagonal-only gives 18')
# Incorrect covariance is external evidence failure, never repaired.
for value in (np.eye(7)*-1, np.eye(6), cov+np.triu(np.ones((7,7))*1e-4,1)):
    changed=copy.deepcopy(row);changed['covariance']=value.tolist()
    try:score(changed,inputs,truth,criteria)
    except ValueError:continue
    raise AssertionError('invalid covariance accepted')
record('negative, wrong-order/shape, nonsymmetric covariance rejected')
# Nonzero translation and full pi symmetry cannot change matching corner positions.
truth['pose'][0][3]=.83;truth['pose'][1][3]=-.21
changed=copy.deepcopy(row);changed['pose']=copy.deepcopy(truth['pose']);changed['pose'][0][0]=-1.;changed['pose'][1][1]=-1.;changed['dimensions']=[[.6],[.4],[.23]]
r=score(changed,inputs,truth,criteria);assert r['orientation_error_rad']==r['corner_error_m']==0
record('translated pi-equivalent truth corners score zero')
# Exact one-sided zero-failure limits independently from (1-p)^n=.05.
for n in (30,200,299):assert abs(proportion([False]*n)['upper_one_sided']-(1-.05**(1/n)))<1e-13
record('independent exact zero-failure binomial formula at n=30/200/299')
# Input metadata affects cache identity; truth deliberately separate.
meta={'prior':np.eye(4).tolist(),'frames':[{'camera':1,'stamp_ns':12}]};arrays={'depth':np.ones((3,3),dtype='<f4')}
h=scene_digest(meta,arrays)
for key in ('camera','stamp_ns'):
    changed=copy.deepcopy(meta);changed['frames'][0][key]+=1
    assert scene_digest(changed,arrays)!=h
record('original camera IDs and acquisition stamps bound by digest')
print(json.dumps({'checks':checks,'count':len(checks)},indent=2))

"""Independent original-record audit; requires completed manifest and summary."""
import collections,hashlib,itertools,json,math,pathlib,sys
import numpy as np
from scipy.stats import beta,chi2
path=pathlib.Path(sys.argv[1]);root=pathlib.Path('/tmp/paired-core-verify-20261015')
manifest=json.loads((path/'manifest.json').read_text());summary=json.loads((path/'summary.json').read_text())
assert 'artifacts' in manifest, 'Unsealed/incomplete result manifest'
for name,digest in manifest['artifacts'].items():assert hashlib.sha256((path/name).read_bytes()).hexdigest()==digest,name
for name,digest in manifest['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name,digest in manifest['binaries'].items():
    # Own runs have own build directory, original runs' worker identities are checked separately.
    assert len(digest)==64
rows=[json.loads(line) for line in (path/'requests.jsonl').read_text().splitlines()]
cache=pathlib.Path(manifest['cache']);corners=np.array(list(itertools.product((-1,1),(-1,1),(0,1))))
groups=collections.defaultdict(list);accuracy_checks=0;selection=collections.defaultdict(list);corner_quantiles=[]
for row in rows:
    key=tuple(row[k] for k in ('stage','partition','mode','condition','budget','precision','loss','subset'))
    if row['subset']=='prior':
        assert row['accepted'] is None and row['accepted_wrong'] is None and row['spatially_usable'] is None
        continue
    groups[key].append(row);selection[(row['scene_id'],row['budget'],row['subset'])].append(row)
    assert row['age_s'] is None and row['end_to_end_usable'] is None and not row['tf_admission_exercised']
    if not row['accepted']:
        assert all(row[k] is None for k in ('position_error_m','orientation_error_rad','corner_error_m','joint_nees'))
        assert row['dimension_errors_m']=={} and row['coverage']=={}
        continue
    truth=json.loads((cache/row['scene_id']/'truth.json').read_text());T=np.array(truth['pose']);E=np.array(row['pose']);d=np.array(row['dimensions']).reshape(3)
    translations=np.linalg.norm(T[:3,3]-E[:3,3]);angles=[];alternatives=[T[:3,:3],T[:3,:3]@np.diag([-1,-1,1])]
    for R in alternatives:angles.append(math.acos(np.clip((np.trace(R@E[:3,:3].T)-1)/2,-1,1)))
    chosen=int(np.argmin(angles));assert abs(row['position_error_m']-translations)<1e-12
    assert abs(row['orientation_error_rad']-angles[chosen])<3e-8
    errors={str(a):abs(truth['dimensions'][a]-d[a]) for a in row['dimension_axes']}
    assert all(abs(row['dimension_errors_m'][a]-v)<1e-12 for a,v in errors.items())
    inp=json.loads((cache/row['scene_id']/'inputs.json').read_text());missing=sorted(set(inp['required_dimension_axes'])-set(row['dimension_axes']))
    assert row['missing_required_axes']==missing
    corner=None
    if not missing:
        A=(corners*d/[2,2,1])@E[:3,:3].T+E[:3,3];B=(corners*np.array(truth['dimensions'])/[2,2,1])@alternatives[chosen].T+T[:3,3]
        corner=float(np.sqrt(((A-B)**2).sum(1)).max());assert abs(row['corner_error_m']-corner)<1e-12
    limits=manifest['criteria']['primary'];wrong=bool(translations>limits['position_m'] or angles[chosen]>limits['orientation_rad'] or any(v>limits['dimension_m'] for v in errors.values()) or (corner is not None and corner>limits['corner_m']))
    assert wrong==row['accepted_wrong'];assert row['spatially_usable']==(not wrong and not missing)
    cov=np.array(row['covariance']);assert cov.shape==(6+len(errors),)*2 and np.linalg.eigvalsh(cov).min()>0
    D=alternatives[chosen]@E[:3,:3].T
    vee=np.array([D[2,1]-D[1,2],D[0,2]-D[2,0],D[1,0]-D[0,1]])/2
    angle=angles[chosen];omega=vee*(angle/math.sin(angle) if angle>1e-8 else 1.)
    err=np.r_[T[:3,3]-E[:3,3],omega,[truth['dimensions'][a]-d[a] for a in row['dimension_axes']]]
    nees=float(err@np.linalg.inv(cov)@err);pose_nees=float(err[:6]@np.linalg.inv(cov[:6,:6])@err[:6])
    assert abs(row['joint_nees']-nees)<1e-7*max(1,nees)
    for confidence in (.90,.95,.99):
        assert row['coverage'][str(confidence)]['pose']==bool(pose_nees<=chi2.ppf(confidence,6))
        assert row['coverage'][str(confidence)]['joint']==bool(nees<=chi2.ppf(confidence,len(err)))
    accuracy_checks+=1
for k,variants in selection.items():
    assert len(variants)==4 and len({r['selected_data_sha256'] for r in variants})==1
for key,rs in groups.items():
    s=next(s for s in summary['groups'] if tuple(s[k] for k in ('stage','partition','mode','condition','budget','precision','loss','subset'))==key)
    accepted=[r for r in rs if r['accepted']];wrong=[r for r in accepted if r['accepted_wrong']]
    assert len(rs)==s['requests']==len({r['scene_id'] for r in rs})
    assert s['acceptance']['count']==len(accepted) and s['acceptance']['total']==len(rs)
    assert s['accepted_wrong']['count']==len(wrong) and s['accepted_wrong']['total']==len(accepted)
    assert s['wrong_all_requests']['count']==len(wrong) and s['wrong_all_requests']['total']==len(rs)
    assert s['spatial_usability']['count']==sum(r['spatially_usable'] for r in rs)
    if accepted:
        upper=1. if len(wrong)==len(accepted) else float(beta.ppf(.95,len(wrong)+1,len(accepted)-len(wrong)))
        assert abs(upper-s['accepted_wrong']['upper_one_sided'])<1e-14
        for metric in ('position_error_m','orientation_error_rad'):
            assert np.allclose(np.quantile([r[metric] for r in accepted],[.5,.95,1]),[s[metric][x] for x in ('median','p95','maximum')])
        values=[r['corner_error_m'] for r in accepted if r['corner_error_m'] is not None]
        corner_quantiles.append({'group':key,'accepted_complete':len(values),'corner_error_m_median_p95_max':list(np.quantile(values,[.5,.95,1])) if values else None})
for comparison in summary['paired_comparisons']:
    common=tuple(comparison[k] for k in ('stage','partition','mode','condition','budget','precision','loss'))
    a={r['scene_id']:r for r in groups[common+('AB',)]};b={r['scene_id']:r for r in groups[common+(comparison['comparison'][-1],)]}
    assert a.keys()==b.keys()
    for metric in ('accepted','spatially_usable','accepted_wrong'):
        expected=sum(int(a[i][metric])-int(b[i][metric]) for i in a)/len(a)
        assert abs(comparison[metric+'_delta']['mean']-expected)<1e-14
    assert comparison['common_accepted_scenes']==sum(a[i]['accepted'] and b[i]['accepted'] for i in a)
# Independently check the unchanged-prior tangent -> pose map at nonzero position.
import yaml
model=yaml.safe_load(pathlib.Path(manifest['model_file']).read_text());P=np.asarray(model['prior_covariance']['matrix'])
prior_count=0
for r in rows:
    if r['subset']!='prior':continue
    pos=np.asarray(r['pose'])[:3,3];x,y,z=pos
    J=np.block([[np.eye(3),np.array([[0,z,-y],[-z,0,x],[y,-x,0]])],[np.zeros((3,3)),np.eye(3)]])
    assert np.allclose(np.asarray(r['covariance']),J@P@J.T,atol=1e-14,rtol=1e-14)
    assert r['dimension_axes']==[] and np.asarray(r['covariance']).shape==(6,6)
    prior_count+=1
# Reproduce scene bootstrap independently, preserving RNG sequence and row pairing.
rng=np.random.default_rng(manifest['criteria']['bootstrap_seed']);bootstrap_checks=0
for key in sorted(groups):
    if key[-1]!='AB':continue
    aa={r['scene_id']:r for r in groups[key]}
    for single in ('A','B'):
        bb={r['scene_id']:r for r in groups[key[:-1]+(single,)]};ids=sorted(aa)
        comparison=next(c for c in summary['paired_comparisons'] if tuple(c[k] for k in ('stage','partition','mode','condition','budget','precision','loss'))==key[:-1] and c['comparison']=='AB-'+single)
        choices=rng.integers(0,len(ids),(manifest['criteria']['bootstrap_repetitions'],len(ids)))
        for metric in ('accepted','spatially_usable','accepted_wrong'):
            differences=np.array([int(aa[i][metric])-int(bb[i][metric]) for i in ids]);means=np.mean(differences[choices],axis=1)
            assert np.allclose(np.quantile(means,[.025,.975]),comparison[metric+'_delta']['paired_95_interval'],atol=1e-14)
            bootstrap_checks+=1
        common=[i for i in ids if aa[i]['accepted'] and bb[i]['accepted']]
        if common:
            differences=np.array([aa[i]['position_error_m']-bb[i]['position_error_m'] for i in common])
            choices=rng.integers(0,len(common),(manifest['criteria']['bootstrap_repetitions'],len(common)))
            assert np.allclose(np.quantile(np.median(differences[choices],axis=1),[.025,.975]),comparison['common_accepted_position_delta_m']['paired_95_interval'],atol=1e-14)
            bootstrap_checks+=1
caps=collections.defaultdict(list)
for r in rows:
    if r['subset']=='prior' or r['budget']!='equal_samples' or r['precision']!='declared' or r['loss']!='huber':continue
    caps[(r['mode'],r['condition'],r['subset'])].append(r['surface_effective_cap_before_correspondence'])
cap_ranges=[{'mode':k[0],'condition':k[1],'subset':k[2],'minimum':min(v),'maximum':max(v)} for k,v in sorted(caps.items())]
print(json.dumps({'path':str(path),'artifact_hashes_verified':len(manifest['artifacts']),'source_hashes_verified':len(manifest['source_sha256']),'rows':len(rows),'sensor_requests':sum(map(len,groups.values())),'groups':len(groups),'prior_references':prior_count,'bootstrap_intervals_verified':bootstrap_checks,'accepted_rows_independently_rescored':accuracy_checks,'scene_sizes':dict(collections.Counter(len(v) for v in groups.values())),'equal_sample_surface_cap_ranges':cap_ranges,'corner_quantiles_supplement':corner_quantiles},indent=2))

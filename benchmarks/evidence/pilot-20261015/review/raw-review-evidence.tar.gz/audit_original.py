import collections,hashlib,json,pathlib,sys
import numpy as np
sys.path.insert(0,'/tmp/paired-core-verify-20261015/benchmarks')
from scenes import scene_digest
base=pathlib.Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
cache=base/pathlib.Path('/tmp/paired-current-bundle.txt').read_text().strip()/'cache'
index=json.loads((cache/'index.json').read_text());counts=collections.Counter();digests=set();nonidentity=0
for entry in index['scenes']:
    folder=cache/entry['scene_id'];inp=json.loads((folder/'inputs.json').read_text());truth=json.loads((folder/'truth.json').read_text())
    assert hashlib.sha256((folder/'truth.json').read_bytes()).hexdigest()==entry['truth_sha256']
    with np.load(folder/'pixels.npz') as arrays:
        assert scene_digest(inp,arrays)==inp['cache_digest']==entry['cache_digest']
        for f in inp['frames']:
            assert np.array_equal(arrays[f['key']+'_tf'],f['body_camera'])
    assert inp['configured_sigmas']==[.003,.006]
    assert sorted(set(f['camera'] for f in inp['frames']))==([0] if inp['condition']=='dropout' else [0,1])
    for cam in {f['camera'] for f in inp['frames']}:
        frames=[f for f in inp['frames'] if f['camera']==cam]
        assert [f['frame'] for f in frames]==list(range(6))
        assert [f['stamp_ns'] for f in frames]==[1050000000+i*100000000 for i in range(6)]
    assert (truth['dimensions']==[.6,.4,.23]) if inp['mode']==0 else (all(.012<=truth['dimensions'][i]-[.6,.4][i]<=.025 for i in (0,1)))
    counts[f"{inp['mode']}-{inp['condition']}"]+=1;digests.add(inp['cache_digest'])
    nonidentity+=not np.allclose(truth['pose'],np.eye(4))
assert len(index['scenes'])==len(digests)==600 and set(counts.values())=={30} and len(counts)==20 and nonidentity==600
print(json.dumps({'cache':str(cache),'index_sha256':hashlib.sha256((cache/'index.json').read_bytes()).hexdigest(),'scenes_verified':600,'unique_input_digests':600,'nonidentity_truth_scenes':nonidentity,'groups':dict(counts),'generator_matches_reviewed_revision':index['generator_sha256']==hashlib.sha256(pathlib.Path('/tmp/paired-core-verify-20261015/benchmarks/scenes.py').read_bytes()).hexdigest()},indent=2))

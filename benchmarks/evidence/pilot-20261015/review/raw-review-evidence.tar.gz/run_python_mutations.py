import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/tmp/paired-core-verify-20261015');evidence=pathlib.Path(__file__).parent
results=[]
for name,file,old,new,test in [
('cross-covariance-discarded','metrics.py',"covariance = np.asarray(row['covariance']); error = np.asarray(error)","covariance = np.diag(np.diag(np.asarray(row['covariance']))); error = np.asarray(error)",'test_benchmark.GeometryAndStatistics.test_joint_cross_covariance_is_used'),
('cache-validation-bypassed','paired.py',"if scene_digest(inputs, arrays) != inputs['cache_digest']:","if False and scene_digest(inputs, arrays) != inputs['cache_digest']:",'test_benchmark.WorkerIntegration.test_same_cached_pixels_and_budgets_across_real_ablations')]:
    path=root/'benchmarks'/file;original=path.read_text();assert original.count(old)==1
    mutated=original.replace(old,new);source=evidence/(name+'-'+file);source.write_text(mutated)
    try:
        path.write_text(mutated)
        with (evidence/'logs'/(name+'.log')).open('w') as out:
            proc=subprocess.run([sys.executable,'-s','-m','unittest',test,'-v'],cwd=root/'benchmarks',stdout=out,stderr=subprocess.STDOUT)
        results.append({'name':name,'returncode':proc.returncode,'mutated_source_sha256':hashlib.sha256(mutated.encode()).hexdigest(),'test':test})
        assert proc.returncode!=0
    finally:path.write_text(original)
print(json.dumps(results,indent=2))

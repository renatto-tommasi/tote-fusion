#!/bin/bash
# Reviewer build/run commands. New locations required for all replay outputs.
set -euo pipefail
cd /tmp/paired-core-verify-20261015
mkdir -p build/tote_fusion
python3 -s benchmarks/instrument.py src/tote_fusion/src/core.cpp build/tote_fusion/equal_precision_core.cpp
flags=(-std=c++17 -O2 -g -Wall -Wextra -Wpedantic -I src/tote_fusion/include -I /usr/include/eigen3)
g++ "${flags[@]}" -c src/tote_fusion/src/geometry.cpp -o build/tote_fusion/geometry.o
g++ "${flags[@]}" -c src/tote_fusion/src/core.cpp -o build/tote_fusion/core.o
g++ "${flags[@]}" -c build/tote_fusion/equal_precision_core.cpp -o build/tote_fusion/equal_core.o
g++ "${flags[@]}" benchmarks/worker.cpp build/tote_fusion/core.o build/tote_fusion/geometry.o -lyaml-cpp -lcrypto -o build/tote_fusion/benchmark_declared
g++ "${flags[@]}" -DTOTE_EQUAL_PRECISION_WORKER benchmarks/worker.cpp build/tote_fusion/equal_core.o build/tote_fusion/geometry.o -lyaml-cpp -lcrypto -o build/tote_fusion/benchmark_equal
python3 -s -m unittest discover -s benchmarks -p test_benchmark.py -v

from pathlib import Path
import subprocess

root = Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
source = (root/'benchmarks/ros_replay.py').read_text()
for arm in ('fresh-v2',):
    dev = Path('/tmp/paired-transport-probe-'+arm)
    dev.mkdir()
    archive = subprocess.run(['git', 'archive', '76ff1f3'], cwd=root, check=True, stdout=subprocess.PIPE).stdout
    subprocess.run(['tar', '-xf', '-', '-C', str(dev)], input=archive, check=True)
    (dev/'build').symlink_to(root/'build')
    (dev/'benchmarks/ros-contract.md').write_bytes((root/'benchmarks/ros-contract.md').read_bytes())
    s = source.replace('import uuid', 'import uuid\nfrom rclpy.parameter_client import AsyncParameterClient\nfrom diagnostic_msgs.msg import DiagnosticArray')
    s = s.replace('        self.collecting = {}', """        self.collecting = {}; self.probe_diagnostics=[]
        self.probe_sub=self.node.create_subscription(DiagnosticArray, '/diagnostics', lambda m:self.probe_diagnostics.append({'stamp_ns':ns(m.header.stamp),'messages':[v.message for v in m.status]}),10)""", 1)
    s = s.replace("request_object = identity+'-'+request_uuid.hex[:8]; self.collecting.clear()",
                  "request_object = identity+'-'+request_uuid.hex[:8]; self.collecting.clear(); self.probe_diagnostics.clear()")
    if arm == 'reused':
        s = s.replace("action_name = '/paired/estimate_'+request_uuid.hex", "action_name = '/tote_fusion/estimate'")
    needle = '                    future = client.send_goal_async(goal, goal_uuid=goal_uuid); self.wait(future.done)'
    assert s.count(needle) == 1
    s = s.replace(needle, """                    endpoints=[{'node':v.node_name,'gid':list(v.endpoint_gid)} for v in self.node.get_publishers_info_by_topic(action_name+'/_action/feedback')]
                    (output/(identity+'-endpoints.json')).write_text(json.dumps({'action_name':action_name,'goal_uuid':goal_key.hex(),'endpoints':endpoints,'pid':self.process.pid},indent=2)+'\\n')
                    future = client.send_goal_async(goal, goal_uuid=goal_uuid)
                    try:
                        self.wait(future.done)
                    except TimeoutError:
                        parameter=AsyncParameterClient(self.node,'tote_fusion')
                        heartbeat=parameter.get_parameters(['validation_profile']); started=time.monotonic_ns()
                        try:
                            self.wait(heartbeat.done,2)
                            health={'parameter_values':[v.string_value for v in heartbeat.result().values]}
                        except TimeoutError:
                            health={'parameter_timeout':True}
                        health.update(wall_ns=time.monotonic_ns(),duration_s=(time.monotonic_ns()-started)/1e9,process_status=self.process.poll(),diagnostics=self.probe_diagnostics)
                        (output/(identity+'-heartbeat.json')).write_text(json.dumps(health,indent=2)+'\\n')
                        raise""")
    needle = '                    released_wall = time.monotonic_ns(); self.origin_wall = released_wall; self.origin_ros = sent_ros; self.hold = None'
    assert s.count(needle) == 1
    s = s.replace(needle, '                    cancellation=handle.cancel_goal_async(); self.wait(cancellation.done); self.wait(lambda:bool(finished_times))\n'+needle)
    s = s.replace("for subset in ('A', 'B', 'AB'):", "for subset in ('A',):")
    needle = '                            row = fresh_request(inputs, arrays, subset, variant, model, args.output)'
    assert s.count(needle) == 1
    s = s.replace(needle, """                            try:
                                row = fresh_request(inputs, arrays, subset, variant, model, args.output)
                            except (RuntimeError,TimeoutError) as error:
                                failure=context|{'classification':'protocol_failure','type':type(error).__name__,'message':str(error)}
                                with (args.output/'probe-failures.jsonl').open('a') as failed: failed.write(json.dumps(failure)+'\\n')
                                print('FAILED',context,str(error),flush=True)
                                continue""")
    s = s.replace("    manifest = {'stage': 'ros',", f"    manifest = {{'stage': 'transport_probe_{arm}',")
    s = s.replace('json.dumps(summary(rows, criteria)', "json.dumps({'requests':len(rows),'codes':{c:sum(r['code']==c for r in rows) for c in sorted({r['code'] for r in rows})}}")
    (dev/'benchmarks/transport_probe.py').write_text(s)
    print(dev)

"""Recompute complete confirmation cache identities without importing scene generator."""
import collections,hashlib,json
from pathlib import Path
import numpy as np
ROOT=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
cache=ROOT/'benchmarks/runs/confirmation-v1.PYMPBs/cache'
index=json.loads((cache/'index.json').read_text()); pilot=json.loads((ROOT/'benchmarks/runs/pilot-v1.zhtlKh/cache/index.json').read_text())
assert index['partition']=='confirmation' and index['seed_span']==[200000,200199]
assert index['generator_sha256']==hashlib.sha256((ROOT/'benchmarks/scenes.py').read_bytes()).hexdigest()
assert len(index['scenes'])==len({r['scene_id'] for r in index['scenes']})==1200
counts=collections.Counter(); seeds=set()
for entry in index['scenes']:
 folder=cache/entry['scene_id']; inputs=json.loads((folder/'inputs.json').read_text())
 assert inputs['partition']=='confirmation' and 200000<=inputs['seed']<=200199
 assert 'truth' not in inputs and 'pose_truth' not in inputs
 seeds.add(inputs['seed']); counts[(inputs['mode'],inputs['condition'])]+=1
 truth=(folder/'truth.json').read_bytes(); assert hashlib.sha256(truth).hexdigest()==entry['truth_sha256']
 pixels=hashlib.sha256()
 with np.load(folder/'pixels.npz') as arrays:
  for name in sorted(arrays.files):
   a=np.ascontiguousarray(arrays[name]); pixels.update(name.encode()); pixels.update(a.dtype.str.encode()); pixels.update(str(a.shape).encode()); pixels.update(a.tobytes())
 metadata={k:v for k,v in inputs.items() if k!='cache_digest'}
 combined=hashlib.sha256(json.dumps(metadata,sort_keys=True,allow_nan=False).encode()+pixels.hexdigest().encode()).hexdigest()
 assert combined==entry['cache_digest']==inputs['cache_digest']
assert counts==collections.Counter({(mode,condition):200 for mode in (0,1) for condition in ('noise','shared_bias','weak_complementary')})
assert not seeds.intersection(int(r['scene_id'].rsplit('-',1)[1]) for r in pilot['scenes'])
print('PASS all1200 confirmation cache pixel/metadata/truth identities;6groups*200; pilot seeds disjoint')
print('cache index SHA256',hashlib.sha256((cache/'index.json').read_bytes()).hexdigest())

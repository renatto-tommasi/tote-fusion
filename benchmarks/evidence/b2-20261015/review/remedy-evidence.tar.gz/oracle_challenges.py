"""Exercise covariance scorer and UUID-specific readiness with isolated mutations."""
import copy,json,sys,types
from pathlib import Path
sys.path.insert(0,str(Path('benchmarks').resolve()))
import numpy as np
from audit import CACHE,audit
source=Path('benchmarks/metrics.py').read_text()
old="row['joint_nees'] = float(error @ np.linalg.solve(covariance, error))"
assert source.count(old)==1
changed=source.replace(old,"row['joint_nees'] = float(np.sum(error**2/np.diag(covariance)))")
Path('metrics-diagonal-mutant.py').write_text(changed)
mod=types.ModuleType('broken_metrics'); exec(compile(changed,'metrics-diagonal-mutant.py','exec'),mod.__dict__)
rows=[json.loads(l) for l in Path('native-controls/requests.jsonl').read_text().splitlines()]
row=next(r for r in rows if r['mode']==1 and r['subset']=='AB' and r['transport_variant']=='normal' and r['accepted'])
folder=CACHE/row['scene_id']; inputs=json.loads((folder/'inputs.json').read_text()); truth=json.loads((folder/'truth.json').read_text()); criteria=json.loads(Path('benchmarks/criteria.json').read_text())
broken=mod.score(copy.deepcopy(row),inputs,truth,criteria)
try: audit([broken])
except AssertionError as e:
    assert str(e)=='joint covariance score'; print('DETECTED isolated covariance cross-term omission:',str(e))
else: raise AssertionError('cross-term mutant survived')
assert audit([row])==1; print('RESTORED full covariance oracle passes')
from ros_replay import Replay
from tote_fusion_interfaces.action import EstimateTote
from unique_identifier_msgs.msg import UUID
replay=Replay.__new__(Replay); replay.collecting={}
expected=bytes(range(16)); unrelated=bytes(reversed(range(16)))
message=EstimateTote.Impl.FeedbackMessage(); message.feedback.state='COLLECTING'; message.goal_id=UUID(uuid=list(unrelated))
replay.feedback(message)
assert unrelated in replay.collecting and expected not in replay.collecting, 'unrelated feedback authorized release'
print('PASS UUID mismatch does not satisfy production exact-goal readiness predicate')
# The representative readiness regression uses the actual source predicate seam.
actual=Path('benchmarks/ros_replay.py').read_text(); needle='goal_key in self.collecting'
assert actual.count(needle)==1
Path('uuid-gate-mutant.txt').write_text(actual.replace(needle,'bool(self.collecting)'))
predicate=eval(compile('lambda goal_key,self: bool(self.collecting)','uuid-gate-mutant','eval'))
try:
    assert not predicate(expected,replay), 'wrong UUID released acquisition'
except AssertionError as e: print('DETECTED isolated readiness predicate mutation:',str(e))
else: raise AssertionError('UUID predicate mutant survived')
message.goal_id=UUID(uuid=list(expected)); replay.feedback(message)
assert expected in replay.collecting; print('RESTORED exact-goal feedback permits readiness')

wrong=copy.deepcopy(row); wrong['goal_uuid']='00'*16
try: audit([wrong])
except AssertionError as e:
    assert str(e)=='candidate goal UUID correlation'; print('DETECTED changed result-goal UUID:',str(e))
else: raise AssertionError('result UUID mismatch survived')
assert audit([row])==1; print('RESTORED result candidate hash matches exact goal UUID')

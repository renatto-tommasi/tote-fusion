"""Isolated source mutants and independent TF publication capture."""
import hashlib, json, os, sys, time, types
from pathlib import Path
sys.path.insert(0,str(Path('benchmarks').resolve()))
import numpy as np
import rclpy
from scipy.spatial.transform import Rotation, Slerp
from audit import CACHE

mutation,variant=sys.argv[1:3]; output=Path('challenge-'+mutation); output.mkdir(exist_ok=False)
source=Path('benchmarks/ros_replay.py').read_text()
replacements={
 'timing':('(finished_wall-sent_wall)/1e9','(finished_wall-ack_wall)/1e9'),
 'byte':("payload = arrays[frame['key']+'_'+kind].tobytes();", "payload = arrays[frame['key']+'_'+kind].tobytes(); payload = bytes([payload[0]^1])+payload[1:];"),
 'tf':('support = matrix.copy(); support[:3, 3] += velocity*delta','support = matrix.copy(); support[:3, 3] += velocity*delta + np.array([.01,0,0])')}
if mutation!='restored':
    old,new=replacements[mutation]; assert source.count(old)==1; source=source.replace(old,new)
(output/'executed-replay.py').write_text(source)
module=types.ModuleType('replay_under_review'); module.__file__=str(Path('benchmarks/ros_replay.py').resolve())
exec(compile(source,module.__file__,'exec'),module.__dict__)
os.environ['ROS_DOMAIN_ID']='92'; events=[]
class Capture:
    def __init__(self,publisher): self.publisher=publisher
    def publish(self,message):
        wall=time.monotonic_ns()
        for tf in message.transforms:
            p,q=tf.transform.translation,tf.transform.rotation
            events.append({'wall':wall,'stamp':module.ns(tf.header.stamp),'position':[p.x,p.y,p.z],'quaternion':[q.x,q.y,q.z,q.w]})
        self.publisher.publish(message)
class RecordingReplay(module.Replay):
    def __init__(self,context):
        super().__init__(context)
        self.dynamic=Capture(self.dynamic)
module.Replay=RecordingReplay
folder=CACHE/'pilot-m0-tf_gap-100000'; inputs=json.loads((folder/'inputs.json').read_text())
with np.load(folder/'pixels.npz') as arrays:
    row=module.fresh_request(inputs,arrays,'AB',variant,Path('src/tote_fusion/config/tote_model.yaml'),output)
truth=json.loads((folder/'truth.json').read_text()); criteria=json.loads(Path('benchmarks/criteria.json').read_text())
row=module.score(row,inputs,truth,criteria)
row['end_to_end_usable']=bool(row['spatially_usable'] and row['send_to_result_s']<=3 and row['age_s']<=2 and row['wall_age_s']<=2) if row['accepted'] else False
(output/'requests.jsonl').write_text(json.dumps(row)+'\n')
(output/'tf-publications.json').write_text(json.dumps(events,indent=2))
if variant=='valid_bracket':
    for event in events:
        assert event['wall']>=row['released_wall_ns']+event['stamp']-row['released_ros_ns'], 'noncausal TF support'
    for frame in inputs['frames']:
        if frame['camera']!=1: continue
        stamp=row['released_ros_ns']+frame['stamp_ns']-1_000_000_000
        before=max((e for e in events if e['stamp']<=stamp),key=lambda e:e['stamp'])
        after=min((e for e in events if e['stamp']>=stamp),key=lambda e:e['stamp'])
        assert after['stamp']-before['stamp']==80_000_000, 'wrong bracket gap'
        alpha=(stamp-before['stamp'])/(after['stamp']-before['stamp'])
        p=(1-alpha)*np.array(before['position'])+alpha*np.array(after['position'])
        r=Slerp([0,1],Rotation.from_quat([before['quaternion'],after['quaternion']]))([alpha]).as_matrix()[0]
        target=np.array(frame['body_camera'])
        assert np.allclose(p,target[:3,3],rtol=0,atol=1e-12) and np.allclose(r,target[:3,:3],rtol=0,atol=1e-12), 'TF interpolation does not reproduce cached acquisition pose'
from audit import audit
audit([row]); print('independent challenge oracle PASS',mutation)

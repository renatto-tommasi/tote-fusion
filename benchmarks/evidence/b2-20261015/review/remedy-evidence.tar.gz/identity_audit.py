import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def audit(folder, revision):
    folder=Path(folder); manifest=json.loads((folder/'manifest.json').read_text())
    for name,expected in manifest['source_sha256'].items():
        content=subprocess.check_output(['git','show',revision+':'+name],cwd=ROOT)
        assert hashlib.sha256(content).hexdigest()==expected, ('source identity',name)
    for name,expected in manifest.get('artifacts',{}).items():
        assert digest(folder/name)==expected, ('artifact identity',name)
    if 'node_sha256' in manifest: assert digest(ROOT/'build/tote_fusion/tote_fusion_node')==manifest['node_sha256']
    if 'binaries' in manifest:
        for name,expected in manifest['binaries'].items(): assert digest(ROOT/'build/tote_fusion'/('benchmark_'+name))==expected
        assert digest(ROOT/'build/tote_fusion/equal_precision_core.cpp')==manifest['instrumented_core_sha256']
    print(folder,'identity PASS','artifacts',len(manifest.get('artifacts',{})),'sources',len(manifest['source_sha256']))

if __name__=='__main__': audit(sys.argv[1],sys.argv[2])

import json,sys
from pathlib import Path

def audit(folder,expected):
 folder=Path(folder); rows=[json.loads(l) for l in (folder/'requests.jsonl').read_text().splitlines()]
 contexts=[json.loads(l) for l in (folder/'contexts.jsonl').read_text().splitlines()]
 assert len(rows)==len(contexts)==expected,'missing lifecycle'
 previous=0
 for row,context in zip(rows,contexts):
  assert row['context_lifecycle']==context,'row/context mismatch'
  assert context['context_closed'] is True,'unclosed context'
  assert previous<context['started_wall_ns']<=context['ready_wall_ns']<=row['sent_wall_ns']<=row['ack_wall_ns']<=row['result_wall_ns']<=context['teardown_started_wall_ns']<=context['finished_wall_ns'],'lifecycle order'
  previous=context['finished_wall_ns']
  assert row['action_name']=='/tote_fusion/estimate','unplanned action remap'
 print('PASS fresh-context lifecycle',folder,len(contexts))

if __name__=='__main__':audit(sys.argv[1],int(sys.argv[2]))

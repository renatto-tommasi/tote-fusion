import json,re
from pathlib import Path
import numpy as np
ROOT=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
summary=json.loads((ROOT/'benchmarks/runs/confirmation-v1.PYMPBs/results/summary.json').read_text())
groups={(r['mode'],r['condition'],r['budget'],r['subset']):r for r in summary['groups'] if r['precision']=='declared' and r['loss']=='huber'}
text=(ROOT/'benchmarks/results-confirmation-20261015.md').read_text();budget=None;count=0
for line in text.splitlines():
 if line.startswith('## '):budget={'## Equal capture time':'equal_time','## Equal raw sample control':'equal_samples'}.get(line)
 if budget is not None and (line.startswith('| Pose |') or line.startswith('| Geometry |')):
  fields=[f.strip() for f in line.strip('|').split('|')];mode=0 if fields[0]=='Pose' else 1;condition=fields[1]
  a,b,ab=[groups[(mode,condition,budget,s)] for s in ('A','B','AB')]
  assert list(map(int,fields[2:6]))==[a['spatial_usability']['count'],b['spatial_usability']['count'],ab['spatial_usability']['count'],ab['acceptance']['count']]
  assert fields[6]==str(ab['accepted_wrong']['count'])+'/'+str(ab['accepted_wrong']['total'])
  expected='—' if not ab['acceptance']['count'] else str(ab['coverage_95_joint']['count'])+'/'+str(ab['coverage_95_joint']['total'])
  assert fields[7]==expected
  expected='—' if ab['position_error_m'] is None else f"{ab['position_error_m']['p95']*1000:.3f}"
  assert fields[8]==expected,(fields,expected);count+=1
assert count==12
for budget in ('equal_time','equal_samples'):
 for subset in ('A','B','AB'):assert groups[(1,'noise',budget,subset)]['spatial_usability']['count']==0
for prior in summary['prior_reference']:
 assert np.isclose(prior['position_error_m']['median']*1000,20.494,atol=.0005)
 assert np.isclose(prior['orientation_error_rad']['median']*180/np.pi,3)
comparisons={(r['mode'],r['condition'],r['budget'],r['comparison']):r for r in summary['paired_comparisons'] if r['precision']=='declared' and r['loss']=='huber'}
for budget,expected in [('equal_time',(-.03,[-.055,-.01],-.0465,[-.0636,-.0291])),('equal_samples',(-.015,[-.045,.015],.0386,[-.0030,.0591]))]:
 c=comparisons[(0,'noise',budget,'AB-A')]
 assert np.isclose(c['spatially_usable_delta']['mean'],expected[0])
 assert np.allclose(c['spatially_usable_delta']['paired_95_interval'],expected[1])
 assert np.isclose(c['common_accepted_position_delta_m']['median']*1000,expected[2],atol=.00005)
 assert np.allclose(np.array(c['common_accepted_position_delta_m']['paired_95_interval'])*1000,expected[3],atol=.00005)
c=comparisons[(0,'noise','equal_time','AB-B')]
assert c['spatially_usable_delta']['mean']==0 and np.allclose(c['spatially_usable_delta']['paired_95_interval'],[-.035,.035])
assert np.isclose(-c['common_accepted_position_delta_m']['median']*1000,.1618,atol=.00005)
assert groups[(0,'shared_bias','equal_time','AB')]['coverage_95_joint']==groups[(0,'shared_bias','equal_time','AB')]['accepted_wrong']
print('PASS 12 core presentation-table rows and quoted primary/prior/paired/shared-bias claims')

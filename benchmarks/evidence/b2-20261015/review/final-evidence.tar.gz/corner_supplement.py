import collections,csv,json
from pathlib import Path
import numpy as np
source=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion/benchmarks/runs/confirmation-v1.PYMPBs/results')
rows=[json.loads(l) for l in (source/'requests.jsonl').read_text().splitlines()]
groups=collections.defaultdict(list);names=('partition','mode','condition','budget','precision','loss','subset')
for row in rows:
 if row['subset']!='prior':groups[tuple(row[k] for k in names)].append(row)
result=[]
for key,values in sorted(groups.items()):
 accepted=[r for r in values if r['accepted']];corners=[r['corner_error_m'] for r in accepted if r['corner_error_m'] is not None]
 result.append(dict(zip(names,key))|{'requests':len(values),'accepted':len(accepted),'accepted_with_complete_corner_score':len(corners),'accepted_missing_required_geometry':sum(bool(r['missing_required_axes']) for r in accepted),'corner_error_m':None if not corners else dict(zip(('median','p95','maximum'),map(float,np.quantile(corners,[.5,.95,1]))))})
Path('core-corner-supplement.json').write_text(json.dumps({'source':str(source),'scope':'Accepted complete-geometry outer-envelope corner errors; missing required geometry is retained in a separate accepted denominator. No ROS timing or hardware claim.','groups':result},indent=2)+'\n')
summary=json.loads((source/'summary.json').read_text());primary=[]
lookup={(g['mode'],g['condition'],g['budget'],g['subset']):g for g in result if g['precision']=='declared' and g['loss']=='huber'}
for g in summary['groups']:
 if g['precision']!='declared' or g['loss']!='huber':continue
 c=lookup[(g['mode'],g['condition'],g['budget'],g['subset'])]
 primary.append({k:g[k] for k in ('mode','condition','budget','subset')}|{'requests':g['requests'],'accepted':g['acceptance']['count'],'spatially_useful':g['spatial_usability']['count'],'wrong':g['accepted_wrong']['count'],'wrong_accepted_upper95':g['accepted_wrong']['upper_one_sided'],'missing_geometry':c['accepted_missing_required_geometry'],'corner_median_m':None if c['corner_error_m'] is None else c['corner_error_m']['median'],'corner_p95_m':None if c['corner_error_m'] is None else c['corner_error_m']['p95']})
with Path('core-primary-supplement.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(primary[0]));w.writeheader();w.writerows(primary)
for r in primary:
 if r['budget']=='equal_time':print(r)

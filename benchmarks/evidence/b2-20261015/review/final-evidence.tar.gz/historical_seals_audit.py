import hashlib,json,tarfile
from pathlib import Path
root=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/verification/paired_ros_review_20261015')
public=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion/benchmarks/evidence/b2-20261015/review')
for name,folder,report in [('original-blocked',root,'review-report.md'),('remedy',root/'v5','remedy-report.md')]:
 m=json.loads((folder/'evidence_manifest.json').read_text())
 assert (public/(name+'-manifest.json')).read_bytes()==(folder/'evidence_manifest.json').read_bytes()
 assert (public/(name+'-report.md')).read_bytes()==(folder/report).read_bytes()
 for filename,digest in m['artifacts'].items():assert hashlib.sha256((folder/filename).read_bytes()).hexdigest()==digest,(name,filename)
 with tarfile.open(public/(name+'-evidence.tar.gz')) as archive:
  entries={v.name:v for v in archive if v.isfile()};assert set(entries)==set(m['artifacts'])|{'evidence_manifest.json'}
  assert archive.extractfile(entries['evidence_manifest.json']).read()==(folder/'evidence_manifest.json').read_bytes()
  for filename,digest in m['artifacts'].items():assert hashlib.sha256(archive.extractfile(entries[filename]).read()).hexdigest()==digest,(name,filename)
 print('PASS original immutable seal and complete public review archive',name,len(m['artifacts']))

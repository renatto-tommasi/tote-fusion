"""Independent complete-population spatial/state/statistical audit; run only sealed bundles."""
import collections, hashlib, itertools, json, sys
from pathlib import Path
import numpy as np
import yaml
from scipy.spatial.transform import Rotation
from scipy.stats import binomtest, chi2
from identity_audit import audit as identities
from native_audit import audit as native
from lifecycle_audit import audit as lifecycle
ROOT=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
CRITERIA=json.loads((ROOT/'benchmarks/criteria.json').read_text())


def close(actual,expected,label):
 if expected is None: assert actual is None,label
 else: assert np.allclose(actual,expected,rtol=1e-9,atol=1e-12), (label,actual,expected)


def spatial(row,inputs,truth):
 if row['accepted'] is False:
  assert all(row[k] is None for k in ('position_error_m','orientation_error_rad','joint_nees','corner_error_m'))
  assert row['accepted_wrong'] is False and row['spatially_usable'] is False
  assert not row['dimension_errors_m'] and not row['coverage']
  return
 pose=np.asarray(row['pose']); actual=np.asarray(truth['pose']); axes=row['dimension_axes']
 choices=[actual[:3,:3],actual[:3,:3]@np.diag([-1,-1,1])]
 rotations=[Rotation.from_matrix(c@pose[:3,:3].T).as_rotvec() for c in choices]
 selected=min(range(2),key=lambda i:np.linalg.norm(rotations[i]))
 error=np.r_[actual[:3,3]-pose[:3,3],rotations[selected]]
 close(row['position_error_m'],np.linalg.norm(error[:3]),'position')
 close(row['orientation_error_rad'],np.linalg.norm(error[3:]),'orientation')
 dimensions=np.asarray(row['dimensions']).reshape(3); missing=sorted(set(inputs['required_dimension_axes'])-set(axes))
 assert row['missing_required_axes']==missing
 dimension_errors={}
 for axis in axes:
  delta=truth['dimensions'][axis]-dimensions[axis];error=np.r_[error,delta];dimension_errors[str(axis)]=abs(delta)
 assert set(row['dimension_errors_m'])==set(dimension_errors)
 for axis,value in dimension_errors.items():close(row['dimension_errors_m'][axis],value,'dimension')
 covariance=np.asarray(row['covariance']); assert covariance.shape==(len(error),len(error))
 assert np.isfinite(covariance).all() and np.allclose(covariance,covariance.T)
 values,vectors=np.linalg.eigh(covariance); assert values.min()>0
 joint=float(np.sum((vectors.T@error)**2/values));close(row['joint_nees'],joint,'NEES full joint')
 values,vectors=np.linalg.eigh(covariance[:6,:6]); pose_nees=float(np.sum((vectors.T@error[:6])**2/values))
 for p in (.9,.95,.99):
  assert row['coverage'][str(p)]=={'joint':bool(joint<=chi2.ppf(p,len(error))),'pose':bool(pose_nees<=chi2.ppf(p,6))}
 corners=None
 if not missing:
  errors=[]
  for x,y,z in itertools.product((-1,1),(-1,1),(0,1)):
   local=np.array([x/2,y/2,z]); observed=pose[:3,:3]@(local*dimensions)+pose[:3,3]
   target=choices[selected]@(local*np.array(truth['dimensions']))+actual[:3,3];errors.append(np.linalg.norm(observed-target))
  corners=max(errors)
 close(row['corner_error_m'],corners,'outer envelope corner')
 for profile in ('primary','secondary'):
  limits=CRITERIA[profile]
  wrong=bool(np.linalg.norm(error[:3])>limits['position_m'] or np.linalg.norm(error[3:6])>limits['orientation_rad'] or any(e>limits['dimension_m'] for e in dimension_errors.values()) or (corners is not None and corners>limits['corner_m']))
  assert row[profile+'_wrong']==wrong
  assert row[profile+'_spatially_usable']==(not wrong and not missing)
 if row['subset']=='prior':
  assert row['accepted'] is None and row['accepted_wrong'] is None and row['spatially_usable'] is None
  assert axes==[]
  for a in (1,0):close(row['reference_dimension_errors_m'][str(a)],abs(truth['dimensions'][a]-[.6,.4,.23][a]),'prior dimension reference')
  base=yaml.safe_load((ROOT/'src/tote_fusion/config/tote_model.yaml').read_text())
  transform=np.eye(6);position=np.array(inputs['prior'])[:3,3]
  transform[:3,3:]=np.column_stack([np.cross(e,position) for e in np.eye(3)])
  close(covariance,transform@np.array(base['prior_covariance']['matrix'])@transform.T,'prior tangent conversion')
 else:
  assert row['accepted_wrong']==row['primary_wrong'] and row['spatially_usable']==row['primary_spatially_usable']


def proportion(actual,values):
 count,total=sum(bool(v) for v in values),len(values)
 assert actual['count']==count and actual['total']==total
 close(actual['fraction'],count/total if total else None,'fraction')
 if not total:
  assert actual['interval'] is None and actual['upper_one_sided'] is None;return
 limits=binomtest(count,total).proportion_ci(.95,method='exact')
 upper=binomtest(count,total).proportion_ci(.9,method='exact').high
 close(actual['interval'],[limits.low,limits.high],'exact binomial interval')
 close(actual['upper_one_sided'],upper,'exact binomial one-sided bound')


def quantile(actual,values):
 if not values:assert actual is None;return
 for name,p in [('median',.5),('p95',.95),('maximum',1)]:close(actual[name],np.quantile(values,p),'quantile '+name)


def statistics(rows,summary,is_ros):
 names=('partition','mode','condition','transport_variant','subset') if is_ros else ('stage','partition','mode','condition','budget','precision','loss','subset')
 groups=collections.defaultdict(list)
 for row in rows:
  if row['subset']!='prior':groups[tuple(row[k] for k in names)].append(row)
 summaries={tuple(g[k] for k in names):g for g in summary['groups']}
 assert set(summaries)==set(groups)
 for key,group in groups.items():
  s=summaries[key];accepted=[r for r in group if r['accepted']]; assert len(group)==s['requests']==(30 if is_ros else 200)
  assert len({r['scene_id'] for r in group})==len(group)
  for field,values in {'acceptance':[r['accepted'] for r in group],'spatial_usability':[r['spatially_usable'] for r in group],'accepted_wrong':[r['accepted_wrong'] for r in accepted],'wrong_all_requests':[r['accepted_wrong'] for r in group],'complete_required_geometry_accepted':[not r['missing_required_axes'] for r in accepted],'coverage_95_joint':[r['coverage']['0.95']['joint'] for r in accepted]}.items():proportion(s[field],values)
  for field in ('position_error_m','orientation_error_rad'):quantile(s[field],[r[field] for r in accepted])
  for axis in ('1','0'):quantile(s['dimension_error_m'][axis],[r['dimension_errors_m'][axis] for r in accepted if axis in r['dimension_errors_m']])
  if is_ros:
   proportion(s['end_to_end_usability'],[r['end_to_end_usable'] for r in group])
   quantile(s['corner_error_m'],[r['corner_error_m'] for r in accepted if r['corner_error_m'] is not None])
   quantile(s['send_to_result_s'],[r['send_to_result_s'] for r in group])
   quantile(s['wall_capture_to_result_s'],[r['wall_age_s'] for r in accepted])
   quantile(s['ros_capture_to_issue_s'],[r['age_s'] for r in accepted])
   assert s['codes']==dict(collections.Counter(r['code'] for r in group))
  else:
   proportion(s['secondary_spatial_usability'],[r['secondary_spatially_usable'] for r in group])
   proportion(s['coverage_95_pose'],[r['coverage']['0.95']['pose'] for r in accepted])
   quantile(s['compute_s'],[r['compute_s'] for r in group])
   assert s['compute_budget_exceeded']==sum(r['compute_s']>3 for r in group)
   assert s['end_to_end_usability'] is None
   assert s['declared_axis_counts']=={str(a):sum(a in r['dimension_axes'] for r in accepted) for a in (1,0)}
   assert s['rejections']==dict(collections.Counter(r['code'] for r in group if not r['accepted']))
   w=s['accepted_wrong'];expected='inconclusive' if not accepted else 'met' if w['upper_one_sided']<=.01 else 'violated' if w['fraction']>.01 else 'inconclusive'
   assert s['false_acceptance_target']==expected and expected!='met'
 if not is_ros:
  priors=collections.defaultdict(list)
  for row in rows:
   if row['subset']=='prior':priors[(row['partition'],row['mode'],row['condition'])].append(row)
  published={tuple(p[k] for k in ('partition','mode','condition')):p for p in summary['prior_reference']}
  assert set(priors)==set(published)
  for key,values in priors.items():
   assert published[key]['scenes']==len(values)==200
   quantile(published[key]['position_error_m'],[r['position_error_m'] for r in values])
   quantile(published[key]['orientation_error_rad'],[r['orientation_error_rad'] for r in values])
 rng=np.random.default_rng(CRITERIA['bootstrap_seed']); comparisons=[]
 for key,group in sorted(groups.items()):
  if key[-1]!='AB':continue
  left={r['scene_id']:r for r in group};ids=sorted(left)
  # Native implementation shares draws between A/B; core draws each comparison.
  if is_ros:shared=rng.integers(0,len(ids),(CRITERIA['bootstrap_repetitions'],len(ids)))
  for single in ('A','B'):
   right={r['scene_id']:r for r in groups[key[:-1]+(single,)]}; assert left.keys()==right.keys()
   draws=shared if is_ros else rng.integers(0,len(ids),(CRITERIA['bootstrap_repetitions'],len(ids)))
   result=dict(zip(names[:-1],key[:-1]));result['comparison']='AB-'+single
   for metric in (('accepted','spatially_usable','end_to_end_usable','accepted_wrong') if is_ros else ('accepted','spatially_usable','accepted_wrong')):
    d=np.array([int(left[i][metric])-int(right[i][metric]) for i in ids]);result[metric+'_delta']={'mean':float(d.mean()),'paired_95_interval':np.quantile(d[draws].mean(1),[.025,.975]).tolist()}
   if not is_ros:
    common=[i for i in ids if left[i]['accepted'] and right[i]['accepted']];result['common_accepted_scenes']=len(common)
    if common:
     d=np.array([left[i]['position_error_m']-right[i]['position_error_m'] for i in common]);draws2=rng.integers(0,len(common),(CRITERIA['bootstrap_repetitions'],len(common)))
     result['common_accepted_position_delta_m']={'median':float(np.median(d)),'paired_95_interval':np.quantile(np.median(d[draws2],axis=1),[.025,.975]).tolist()}
   comparisons.append(result)
 assert len(comparisons)==len(summary['paired_comparisons'])
 for computed,actual in zip(comparisons,summary['paired_comparisons']):
  for key,value in computed.items():
   if isinstance(value,dict):
    for k,v in value.items():close(actual[key][k],v,'paired bootstrap '+key+' '+k)
   else:assert actual[key]==value,(key,actual[key],value)
 return {'groups':len(groups),'paired_comparisons':len(comparisons)}


def run(kind,folder):
 folder=Path(folder);is_ros=kind=='ros';manifest=json.loads((folder/'manifest.json').read_text())
 assert manifest.get('artifacts') and (folder/'summary.json').is_file(),'run not sealed'
 assert not (folder/'protocol-failure.json').exists(),'protocol-failed bundle'
 identities(folder,'c1702adcae00381de21ff35250a171401403887f' if is_ros else '5e890d2')
 rows=[json.loads(l) for l in (folder/'requests.jsonl').read_text().splitlines()]
 assert len(rows)==(540 if is_ros else 30000),'incomplete final population'
 cache=ROOT/('benchmarks/runs/pilot-v1.zhtlKh/cache' if is_ros else 'benchmarks/runs/confirmation-v1.PYMPBs/cache')
 assert hashlib.sha256((cache/'index.json').read_bytes()).hexdigest()==manifest['cache_index_sha256']
 if is_ros:native(rows,cache);lifecycle(folder,540)
 metadata={};matrix=collections.defaultdict(list)
 for row in rows:
  if row['scene_id'] not in metadata:
   path=cache/row['scene_id'];metadata[row['scene_id']]=(json.loads((path/'inputs.json').read_text()),json.loads((path/'truth.json').read_text()))
  inputs,truth=metadata[row['scene_id']];assert row['cache_digest']==inputs['cache_digest']
  assert row['mode']==inputs['mode'] and row['condition']==inputs['condition'] and row['seed']==inputs['seed']
  spatial(row,inputs,truth)
  if not is_ros:
   assert row['age_s'] is None and row['end_to_end_usable'] is None and row['tf_admission_exercised'] is False
   matrix[row['scene_id']].append(row)
  else:assert row['covariance_calibrated'] is False if row['accepted'] else True
 if not is_ros:
  expected={(budget,precision,loss,subset) for budget in ('equal_time','equal_samples') for precision in ('declared','equal') for loss in ('huber','squared') for subset in ('A','B','AB')}
  for scene,values in matrix.items():
   assert len(values)==25 and sum(r['subset']=='prior' for r in values)==1
   assert {(r['budget'],r['precision'],r['loss'],r['subset']) for r in values if r['subset']!='prior'}==expected
   for budget in ('equal_time','equal_samples'):
    for subset in ('A','B','AB'):
     selected=[r for r in values if r['budget']==budget and r['subset']==subset]
     for field in ('selected_data_sha256','fitting_points','held_points','fitting_boundaries','held_boundaries'):
      assert len({r[field] for r in selected})==1,('factor selection drift',scene,budget,subset,field)
 summary=json.loads((folder/'summary.json').read_text());assert summary['criteria']==CRITERIA
 result=statistics(rows,summary,is_ros)|{'kind':kind,'rows':len(rows),'scenes':len(metadata),'accepted_sensor_rows':sum(r['accepted'] is True for r in rows),'wrong_sensor_rows':sum(r['accepted_wrong'] is True for r in rows)}
 print('PASS independent complete population',json.dumps(result))
 Path(kind+'-population-audit.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':run(sys.argv[1],sys.argv[2])

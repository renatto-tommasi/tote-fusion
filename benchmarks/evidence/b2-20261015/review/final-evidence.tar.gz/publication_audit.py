import gzip,hashlib,json,tarfile
from pathlib import Path
ROOT=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
PUBLIC=ROOT/'benchmarks/evidence/b2-20261015'
def digest(data):return hashlib.sha256(data).hexdigest()
def check_bundle(name):
 p=PUBLIC/name;v=json.loads((p/'provenance.json').read_text());original=Path(v['original_directory']);m=json.loads((p/'manifest.json').read_text())
 assert digest((p/'manifest.json').read_bytes())==v['manifest_sha256']==digest((original/'manifest.json').read_bytes())
 h=hashlib.sha256();count=0
 with gzip.open(p/'requests.jsonl.gz','rb') as f:
  for line in f:h.update(line);count+=1
 assert h.hexdigest()==v['requests_uncompressed_sha256']==m['artifacts']['requests.jsonl']
 assert count==v['requests']
 assert digest((p/'summary.json').read_bytes())==m['artifacts']['summary.json']
 with tarfile.open(p/'supporting-artifacts.tar.gz') as archive:
  members={a.name:a for a in archive if a.isfile()};assert set(members)==set(v['supporting_files'])
  assert set(members)==set(m['artifacts'])-{'requests.jsonl','summary.json'}
  for name2,member in members.items():assert digest(archive.extractfile(member).read())==m['artifacts'][name2],name2
 if (p/'cache-index.json').exists():assert digest((p/'cache-index.json').read_bytes())==m['cache_index_sha256']
 if name=='confirmation':
  for name2 in ('core-corner-supplement.json','core-primary-supplement.csv'):assert (p/name2).read_bytes()==Path(name2).read_bytes()
  for name2 in ('generate.log','run.log'):assert (p/name2).read_bytes()==(original.parent/name2).read_bytes()
 print('PASS compact evidence lossless original-artifact identity',name,'rows',count,'supporting files',len(members))

def diagnostics():
 index=json.loads((PUBLIC/'diagnostics-index.json').read_text())
 with tarfile.open(PUBLIC/'diagnostics.tar.gz') as archive:
  members={m.name:m for m in archive if m.isfile()};assert set(members)==set(index)
  for name,record in index.items():
   content=archive.extractfile(members[name]).read();assert len(content)==record['bytes'] and digest(content)==record['sha256']
   assert digest(Path(record['original']).read_bytes())==record['sha256']
 print('PASS diagnostic archive and retained original hashes',len(index))

if __name__=='__main__':
 import sys
 for name in sys.argv[1:]:check_bundle(name)
 diagnostics()

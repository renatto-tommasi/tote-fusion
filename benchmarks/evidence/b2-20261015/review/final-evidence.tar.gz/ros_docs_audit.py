import json
from pathlib import Path
import numpy as np
ROOT=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion')
p=ROOT/'benchmarks/runs/ros-principal-v5';summary=json.loads((p/'summary.json').read_text());rows=[json.loads(l) for l in (p/'requests.jsonl').read_text().splitlines()]
groups={(g['mode'],g['condition'],g['subset']):g for g in summary['groups']}
text=(ROOT/'benchmarks/results-confirmation-20261015.md').read_text();text=text.split('## Native ROS principal pilot')[1];count=0
for line in text.splitlines():
 if line.startswith('| Pose |') or line.startswith('| Geometry |'):
  fields=[f.strip() for f in line.strip('|').split('|')];mode=0 if fields[0]=='Pose' else 1;condition=fields[1]
  a,b,ab=[groups[(mode,condition,s)] for s in ('A','B','AB')]
  assert list(map(int,fields[2:6]))==[a['end_to_end_usability']['count'],b['end_to_end_usability']['count'],ab['end_to_end_usability']['count'],ab['acceptance']['count']]
  assert fields[6]==str(ab['accepted_wrong']['count'])+'/'+str(ab['accepted_wrong']['total'])
  for actual,value in [(fields[7],None if ab['position_error_m'] is None else ab['position_error_m']['p95']*1000),(fields[8],ab['send_to_result_s']['p95']),(fields[9],None if ab['wall_capture_to_result_s'] is None else ab['wall_capture_to_result_s']['p95'])]:
   assert actual==('—' if value is None else f'{value:.3f}'),(fields,actual,value)
  count+=1
assert count==6
accepted=[r for r in rows if r['accepted']]
assert max(r['send_to_result_s'] for r in rows)<3 and max(r['age_s'] for r in accepted)<2 and max(r['wall_age_s'] for r in accepted)<2
for field,target,tolerance in [('send_to_result_s',1.5154,.00005),('age_s',.9185,.00005),('wall_age_s',.9209,.00005),('pre_acquisition_pause_s',.00445,.000005)]:
 values=accepted if field in ('age_s','wall_age_s') else rows
 assert abs(max(r[field] for r in values)-target)<=tolerance,(field,max(r[field] for r in values))
assert all(r['spatially_usable']==r['end_to_end_usable'] for r in rows)
assert sum(r['accepted'] and r['missing_required_axes']!=[] for r in rows if r['mode']==1 and r['condition']=='noise' and r['subset']=='A')==4
assert groups[(0,'shared_bias','AB')]['accepted_wrong']['count']==29==groups[(0,'shared_bias','AB')]['coverage_95_joint']['count']
comparisons={(r['mode'],r['condition'],r['comparison']):r for r in summary['paired_comparisons']}
for single,mean,interval in [('A',0,[-.1,.1]),('B',2/30,[0,5/30])]:
 actual=comparisons[(0,'noise','AB-'+single)]['end_to_end_usable_delta'];assert np.isclose(actual['mean'],mean) and np.allclose(actual['paired_95_interval'],interval)
print('PASS six ROS presentation-table rows, latency/pause/age maxima, completeness, shared-bias coverage and paired claims')

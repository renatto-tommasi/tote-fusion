"""Independent B2 verifier: raw rows against cache and physical spatial oracle."""
import hashlib, itertools, json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.stats import chi2

CACHE=Path('/home/renatto-tommasi/workspaces/avatar_tote_ws/publication/tote-fusion/benchmarks/runs/pilot-v1.zhtlKh/cache')

def audit(rows, cache=CACHE):
    index={r['scene_id']:r for r in json.loads((cache/'index.json').read_text())['scenes']}
    ids=set()
    for row in rows:
        key=(row['scene_id'],row['transport_variant'],row['subset'])
        assert key not in ids, 'duplicate independent scene'; ids.add(key)
        assert len(bytes.fromhex(row['goal_uuid']))==16, 'goal UUID'
        assert row['sent_wall_ns'] <= row['ack_wall_ns'] <= row['released_wall_ns'], 'ack clock order'
        assert row['sent_wall_ns'] <= row['collecting_feedback_wall_ns'] <= row['released_wall_ns'], 'feedback clock order'
        assert np.isclose(row['send_to_result_s'],(row['result_wall_ns']-row['sent_wall_ns'])*1e-9,atol=1e-12), 'send latency'
        assert row['sent_ros_ns']==row['released_ros_ns']==row['clock_anchor']['ros_ns'], 'release clock'
        assert row['released_wall_ns']==row['clock_anchor']['monotonic_ns'], 'release wall'
        assert row['candidate_publications']==int(row['accepted']), 'publication count'
        folder=cache/row['scene_id']; inputs=json.loads((folder/'inputs.json').read_text())
        assert row['cache_digest']==inputs['cache_digest']==index[row['scene_id']]['cache_digest'], 'input identity'
        truthdata=(folder/'truth.json').read_bytes()
        assert hashlib.sha256(truthdata).hexdigest()==index[row['scene_id']]['truth_sha256'], 'truth identity'
        with np.load(folder/'pixels.npz') as arrays:
            for frame in row['delivered']:
                assert frame['wall_ns']>=row['released_wall_ns']+frame['capture_ns']-row['released_ros_ns'], 'causal image'
                for kind in ('depth','mask'):
                    original=arrays[f"c{frame['camera']}_f{frame['frame']}_{kind}"].tobytes()
                    assert hashlib.sha256(original).hexdigest()==frame['payload_sha256'][kind], 'cached payload'
        if not row['accepted']:
            assert all(row[x] is None for x in ('position_error_m','orientation_error_rad','joint_nees','corner_error_m','age_s','wall_age_s')), 'rejected error'
            continue
        assert sum(row['source_frame_counts'])==row['accepted_frames']==len(row['tf_lookup_stamps_ns']), 'frame provenance'
        for name,count in zip(row['source_camera_ids'],row['source_frame_counts']):
            assert count==row['tf_lookup_camera_ids'].count(name), 'camera provenance'
        assert row['last_capture_ns']==max(row['tf_lookup_stamps_ns']), 'capture provenance'
        assert np.isclose(row['age_s'],(row['issue_ns']-row['last_capture_ns'])*1e-9,atol=1e-12), 'ROS age'
        expected_age=(row['result_wall_ns']-row['released_wall_ns']-row['last_capture_ns']+row['released_ros_ns'])*1e-9
        assert np.isclose(row['wall_age_s'],expected_age,atol=1e-12), 'wall age'
        truth=json.loads(truthdata); actual=np.array(truth['pose']); estimate=np.array(row['pose'])
        choices=[actual[:3,:3],actual[:3,:3]@np.diag([-1,-1,1])]
        errors=[Rotation.from_matrix(c@estimate[:3,:3].T).as_rotvec() for c in choices]
        selected=np.argmin([np.linalg.norm(e) for e in errors]); e=np.r_[actual[:3,3]-estimate[:3,3],errors[selected]]
        assert np.isclose(np.linalg.norm(e[:3]),row['position_error_m'],atol=1e-12), 'position score'
        assert np.isclose(np.linalg.norm(e[3:]),row['orientation_error_rad'],atol=1e-12), 'angle score'
        dims=np.asarray(row['dimensions']).reshape(3)
        for axis in row['dimension_axes']:
            e=np.r_[e,truth['dimensions'][axis]-dims[axis]]
        covariance=np.asarray(row['covariance']); vals,vecs=np.linalg.eigh(covariance)
        assert vals.min()>0 and np.allclose(covariance,covariance.T), 'covariance SPD'
        nees=float(np.sum((vecs.T@e)**2/vals))
        assert np.isclose(nees,row['joint_nees'],rtol=1e-10,atol=1e-10), 'joint covariance score'
        assert row['coverage']['0.95']['joint']==(nees <= chi2.ppf(.95,len(e))), 'coverage score'
        assert set(row['missing_required_axes'])==set(inputs['required_dimension_axes'])-set(row['dimension_axes']), 'missing geometry'
        if not row['missing_required_axes']:
            differences=[]
            for x,y,z in itertools.product((-1,1),(-1,1),(0,1)):
                c=np.array([x/2,y/2,z]); a=estimate[:3,:3]@(c*dims)+estimate[:3,3]
                b=choices[selected]@(c*np.array(truth['dimensions']))+actual[:3,3]
                differences.append(np.linalg.norm(a-b))
            assert np.isclose(max(differences),row['corner_error_m'],atol=1e-12), 'corner score'
        expected=row['spatially_usable'] and row['send_to_result_s']<=3 and row['age_s']<=2 and row['wall_age_s']<=2
        assert row['end_to_end_usable']==expected, 'end-to-end usability'
    return len(rows)

if __name__=='__main__':
    import sys
    rows=[json.loads(l) for l in (Path(sys.argv[1])/'requests.jsonl').read_text().splitlines()]
    print('independent raw-cache/spatial/covariance/timing audit passed',audit(rows))
